/*******************************************************
** Program main.cpp
** Author: Allen Chan
** Date: 6/9/19
** Description: add numbers to a linked list and sorting them
** Input: char and int
** Output: runs program
********************************************************/